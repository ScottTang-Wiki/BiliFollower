<?php

namespace MediaWiki\Extension\BiliFollower;

use Parser;

class BiliFollowerHooks {
    
    public static function onParserFirstCallInit(Parser $parser): void {
        $parser->setFunctionHook('bili_fan', [self::class, 'getFollowerCount']);
        $parser->setFunctionHook('bili_fan_percent', [self::class, 'getFollowerPercent']);
        $parser->setFunctionHook('bili_fan_remain', [self::class, 'getFollowerRemain']);
    }
    
    public static function getFollowerCount(Parser $parser, string $userId = '', string $format = ''): string {
        $count = self::fetchFollowerData($userId);
        
        if (!is_numeric($count)) {
            return $count; // 返回错误信息
        }
        
        // 如果指定了R参数，返回纯数字
        if (trim($format) === 'R') {
            return (string)$count;
        }
        
        // 默认返回格式化的数字
        return '<span style="color: #00a1d6; font-weight: bold;">' . number_format($count) . '</span>';
    }
    
    public static function getFollowerPercent(Parser $parser, string $userId = ''): string {
        $count = self::fetchFollowerData($userId);
    
        if (!is_numeric($count)) {
            return '0';
        }
    
        $percent = ($count / 10000); // 除以10000得到百分比
        $percent = min($percent, 100); // 限制最大值为100%
        return number_format($percent, 2);
        }
    
    public static function getFollowerRemain(Parser $parser, string $userId = ''): string {
        $count = self::fetchFollowerData($userId);
        
        if (!is_numeric($count)) {
            return '无法计算';
        }
        
        $remaining = 1000000 - $count;
        if ($remaining <= 0) {
            return '已超过100万！';
        }
        
        return number_format($remaining);
    }
    
    private static function fetchFollowerData(string $userId): string|int {
        $userId = trim($userId);
        
        if (empty($userId)) {
            return '<span style="color: red;">请提供B站UID</span>';
        }
        
        if (!is_numeric($userId)) {
            return '<span style="color: red;">UID必须是数字</span>';
        }
        
        // 优先尝试B站官方API
        $count = self::tryOfficialApi($userId);
        if ($count !== false) {
            return $count;
        }
        
        // 备用第三方API
        $count = self::tryThirdPartyApi($userId);
        if ($count !== false) {
            return $count;
        }
        
        return '<span style="color: orange;">暂时无法获取数据</span>';
    }
    
    private static function tryOfficialApi(string $userId): int|false {
        $url = "https://api.bilibili.com/x/relation/stat?vmid=" . $userId;
        $response = self::makeHttpRequest($url);
        
        if (!$response) {
            return false;
        }
        
        $data = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return false;
        }
        
        if (isset($data['code']) && $data['code'] === 0 && isset($data['data']['follower'])) {
            return (int)$data['data']['follower'];
        }
        
        return false;
    }
    
    private static function tryThirdPartyApi(string $userId): int|false {
        $url = "https://yunapi.cn/api/bilibili_follower?uid=" . $userId;
        $response = self::makeHttpRequest($url);
        
        if (!$response) {
            return false;
        }
        
        $data = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return false;
        }
        
        $followerCount = $data['data']['follower'] ?? $data['follower'] ?? $data['data']['fans'] ?? null;
        
        if ($followerCount && is_numeric($followerCount)) {
            return (int)$followerCount;
        }
        
        return false;
    }
    
    private static function makeHttpRequest(string $url): string|false {
        if (!function_exists('curl_init')) {
            return false;
        }
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_HTTPHEADER => [
                'Accept: application/json',
                'Accept-Language: zh-CN,zh;q=0.9',
                'Referer: https://www.bilibili.com/'
            ]
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($response !== false && $httpCode === 200) {
            return $response;
        }
        
        return false;
    }
}