<?php

$magicWords = [];

$magicWords['en'] = [
    'bili_fan' => [ 0, 'bili_fan' ],
    'bili_fan_percent' => [ 0, 'bili_fan_percent' ],
    'bili_fan_remain' => [ 0, 'bili_fan_remain' ],
];

$magicWords['zh'] = [
    'bili_fan' => [ 0, 'bili_fan', 'b站粉丝' ],
    'bili_fan_percent' => [ 0, 'bili_fan_percent', 'b站粉丝百分比' ],
    'bili_fan_remain' => [ 0, 'bili_fan_remain', 'b站粉丝剩余' ],
];

$magicWords['zh-hans'] = [
    'bili_fan' => [ 0, 'bili_fan', 'b站粉丝' ],
    'bili_fan_percent' => [ 0, 'bili_fan_percent', 'b站粉丝百分比' ],
    'bili_fan_remain' => [ 0, 'bili_fan_remain', 'b站粉丝剩余' ],
];